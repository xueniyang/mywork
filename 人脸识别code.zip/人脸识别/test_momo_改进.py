'''Train CIFAR10 with PyTorch.'''
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import torchvision
import torchvision.transforms as transforms

import os
import argparse

from models import *
from utils import progress_bar

from AutoAugment_master.autoaugment import ImageNetPolicy, CIFAR10Policy, SVHNPolicy, SubPolicy

from vgg_face_dag import vgg_face_dag_momo
from vgg_m_face_bn_dag import  vgg_m_face_bn_dag_momo
from Resnet50_ft_dag import resnet50_ft_dag_momo
from Resnet50_scratch_dag import resnet50_scratch_dag_momo
from Senet50_ft_dag import senet50_ft_dag_momo
from torchvision.models import resnet50
import moco.loader
import moco.builder
import torchvision.models as models

from sklearn.metrics import (brier_score_loss, precision_score, recall_score, f1_score)
from sklearn import metrics
from eval_metrics import plot_roc
import numpy as np
import csv

from sklearn.metrics import confusion_matrix

from tensorboardX import SummaryWriter 
from torch.nn import functional as F
from skimage import io as ski_io
parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.01, type=float, help='learning rate')  # 默认=0.1
parser.add_argument('--resume', '-r', action='store_true',
                    help='resume from checkpoint')
args = parser.parse_args()

device = 'cuda' if torch.cuda.is_available() else 'cpu'

npy_save_here = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/画各种ROC图像_3_模型输出图像编号降序对应'


fold = '0'
PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_train和test的5折验证/26_MTCNN_net:Resnet34ImageNet_lr:0.001_fineturn:False_一人一张_分类威廉和非威廉_第{:s}折_看看每个epoch的test的性能'.format(fold)
# PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_train和test的5折验证/26_MTCNN_net:Resnet18ImageNet_lr:0.001_fineturn:False_一人一张_分类威廉和非威廉_第{:s}折_看看每个epoch的test的性能'.format(fold)
# PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_train和test的5折验证/26_MTCNN_net:mobilenetv2ImageNet_lr:0.001_fineturn:False_一人一张_分类威廉和非威廉_第{:s}折_看看每个epoch的test的性能'.format(fold)
# PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_train和test的5折验证/26_MTCNN_net:vgg16ImageNet_lr:0.001_fineturn:False_一人一张_分类威廉和非威廉_第{:s}折_看看每个epoch的test的性能'.format(fold)
# PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_train和test的5折验证/26_MTCNN_net:vgg19ImageNet_lr:0.001_fineturn:False_一人一张_分类威廉和非威廉_第{:s}折_看看每个epoch的test的性能'.format(fold)
val_ckpt_pth = os.path.join(PATH_to_log_dir, 'ckpt_29.pth')
data_root = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/101_刘惠重新整理数据跑五折交叉检验数据/1_经过mtcnn人脸检测_5折交叉检验数据_分train_val和test/1_经过mtcnn人脸检测_5折交叉检验数据_分train_val和test_{:s}'.format(fold)



state_dict = torch.load(val_ckpt_pth)
val_acc = state_dict['acc']
val_epoch = state_dict['epoch']
val_weight = state_dict['net']
########################################### 加载ImageNet模型 ############################################
# net_name = 'vgg16ImageNet'
# net = torchvision.models.vgg16_bn(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/vgg16_bn-6c64b313.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.classifier[6] = nn.Linear(4096, 2)
# # net.fc = nn.Linear(1000, 2)
# fineturn = True
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.features[37],net.features[38],net.features[39],net.features[40], net.features[41],net.features[42],net.features[43],
#                     net.avgpool, net.classifier, 
#                     # net.fc,
#                     ]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True

# net_name = 'vgg19ImageNet'
# net = torchvision.models.vgg19_bn(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/vgg19_bn-c79401a0.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.classifier[6] = nn.Linear(4096, 2)
# # net.fc = nn.Linear(net.fc.in_features, 2)
# fineturn = True
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.features[27],net.features[28],net.features[29],net.features[30],net.features[31],net.features[32],net.features[33],net.features[34],net.features[35],net.features[36],
#                     net.features[37], net.features[38], net.features[39], net.features[40], net.features[41], net.features[42], net.features[43],net.features[44],net.features[45],net.features[46], net.features[47],net.features[48],net.features[49],
#                     net.features[50],net.features[51],net.features[52],
#                     net.avgpool, net.classifier, 
#                     # net.fc,
#                     ]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True

# net_name = 'Resnet18ImageNet'
# net = torchvision.models.resnet18(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/resnet18-5c106cde.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.fc = nn.Linear(net.fc.in_features, 2)
# fineturn = True
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.layer1, net.layer2, net.layer3, net.layer4, net.avgpool, net.fc]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True            

net_name = 'Resnet34ImageNet'
net = torchvision.models.resnet34(pretrained=False)
weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/resnet34-333f7ec4.pth'
state_dict = torch.load(weights_path)
net.load_state_dict(state_dict)
net.fc = nn.Linear(net.fc.in_features, 2)
fineturn = True
if fineturn:
    for p in net.parameters():
        p.requires_grad=False
    frozen_layers = [net.layer1, net.layer2, net.layer3, net.layer4, net.avgpool, net.fc]
    for layer in frozen_layers:
        for name, value in layer.named_parameters():
            value.requires_grad = True    

# net_name = 'mobilenetv2ImageNet'
# net = torchvision.models.mobilenet_v2(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/mobilenet_v2-b0353104.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# # net.fc = nn.Linear(net.fc.in_features, 2)
# net.classifier[1] = nn.Linear(1280, 2)
# fineturn = True
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.features[10],net.features[11],net.features[12],net.features[13], net.features[14], net.features[15], net.features[16], net.features[17], net.features[18], net.classifier]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True    
########################################################################################################

net = net.to(device)
if device == 'cuda':
    # net = torch.nn.DataParallel(net)
    cudnn.benchmark = True
net.load_state_dict(val_weight)

transform_test = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
])

testset_2 = torchvision.datasets.ImageFolder(
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_mtcnn_256_44_一人一张_威廉_非威廉_5折交叉检验/5_mtcnn_256_44_一人一张_威廉_非威廉/test', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/6_dlib检测并对齐人脸_一人一张_威廉_非威廉_2/test', 
    root= data_root + '/test', 
    transform=transform_test)
testloader_2 = torch.utils.data.DataLoader(
    testset_2, batch_size=1, shuffle=False, num_workers=0, drop_last=False)

criterion = nn.CrossEntropyLoss()

net.eval()

test_loss = 0
correct = 0
total = 0

targets_list = []
predicted_list = []
prob_list = []
with torch.no_grad():
    for batch_idx, (inputs, targets) in enumerate(testloader_2):
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = net(inputs)

        loss = criterion(outputs, targets)
        test_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        progress_bar(batch_idx, len(testset_2), 'Loss_test: %.3f | Acc_test: %.3f%% (%d/%d)'
                        % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

        np.array((predicted != targets).detach().cpu())

        np.where(np.array((predicted != targets).detach().cpu()) == True)

        targets_list.append(targets.cpu())
        predicted_list.append(predicted.cpu())

        prob = F.softmax(outputs, dim=1)[:,1]
        prob_list.append(prob.cpu())


targets_list = torch.cat(targets_list, dim=0)
predicted_list = torch.cat(predicted_list, dim=0)
prob_list = torch.cat(prob_list, dim=0)

np.save(os.path.join(npy_save_here, 'targets_list_{:s}.npy'.format(fold)), np.array(targets_list))
np.save(os.path.join(npy_save_here, 'predicted_list_{:s}.npy'.format(fold)), np.array(predicted_list))
np.save(os.path.join(npy_save_here, 'prob_list_{:s}.npy'.format(fold)), np.array(prob_list))

precision_epoch = precision_score(targets_list, predicted_list)
recall_epoch = recall_score(targets_list, predicted_list)
f1_epoch = f1_score(targets_list, predicted_list)

tn, fp, fn, tp = confusion_matrix(targets_list, predicted_list).ravel()
spec = (tn) / (tn + fp)


fpr, tpr, thresholds = metrics.roc_curve(targets_list, predicted_list)
auc_epoch = metrics.auc(fpr, tpr)

fpr_prob, tpr_prob, thresholds_prob = metrics.roc_curve(targets_list, prob_list)
auc_prob_epoch = metrics.auc(fpr_prob, tpr_prob)

auc_prob_epoch_2 = metrics.roc_auc_score(targets_list,prob_list)

print("")
print('epoch = %d, val_acc = %.3f, test_acc = %.3f, precision_epoch = %.3f, recall_epoch = %.3f, f1_epoch = %.3f, auc_epoch = %.3f, auc_prob_epoch = %.3f, auc_prob_epoch_2 = %.3f, spec = %.3f'%(val_epoch, val_acc, correct/total, precision_epoch, recall_epoch, f1_epoch, auc_epoch, auc_prob_epoch, auc_prob_epoch_2, spec))

