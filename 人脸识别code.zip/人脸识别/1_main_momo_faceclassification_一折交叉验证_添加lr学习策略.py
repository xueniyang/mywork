'''Train CIFAR10 with PyTorch.'''
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import torchvision
import torchvision.transforms as transforms

import os
import argparse

from models import *
from utils import progress_bar

from AutoAugment_master.autoaugment import ImageNetPolicy, CIFAR10Policy, SVHNPolicy, SubPolicy

from vgg_face_dag import vgg_face_dag_momo
from vgg_m_face_bn_dag import  vgg_m_face_bn_dag_momo
from Resnet50_ft_dag import resnet50_ft_dag_momo
from Resnet50_scratch_dag import resnet50_scratch_dag_momo
from Senet50_ft_dag import senet50_ft_dag_momo
from torchvision.models import resnet50
import moco.loader
import moco.builder
import torchvision.models as models

from sklearn.metrics import (brier_score_loss, precision_score, recall_score, f1_score, accuracy_score)
from sklearn import metrics
from eval_metrics import plot_roc
import numpy as np
import csv

from sklearn.metrics import confusion_matrix
import datetime

parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.001, type=float, help='learning rate')  # 默认=0.1
parser.add_argument('--resume', '-r', action='store_true',
                    help='resume from checkpoint')
args = parser.parse_args()


device = 'cuda' if torch.cuda.is_available() else 'cpu'
# device = 'cpu'
best_acc = 0  # best test accuracy
start_epoch = 0  # start from epoch 0 or last checkpoint epoch
best_acc_2 = 0
##################################### 加载模型 ###################################################
# Model
print('==> Building model..')
# net = VGG('VGG19')
# net = ResNet18()
# net = PreActResNet18()
# net = GoogLeNet()
# net = DenseNet121()
# net = ResNeXt29_2x64d()
# net = MobileNet()
# net = MobileNetV2()
# net = DPN92()
# net = ShuffleNetG2()
# net = SENet18()
# net = ShuffleNetV2(1)
# net = EfficientNetB0()
# net = RegNetX_200MF()

###################################### 加载vggface模型 #################################################
# fineturn = False
# net_name = 'vgg16VGGFACE'
# # net = vgg_face_dag_momo()  # 默认加载预训练模型

# net = vgg_m_face_bn_dag_momo(fineturn=fineturn)  # 默认加载预训练模型

# # net = resnet50_ft_dag_momo(fineturn=fineturn)  # 默认加载预训练模型
# # net = resnet50_scratch_dag_momo(fineturn=fineturn)  # 默认加载预训练模型
# # net = senet50_ft_dag_momo(fineturn=fineturn)  # 默认加载预训练模型
########################################################################################################

######################################## 加载moco模型 ###############################################
# net_name = 'res50_moco'
# net = resnet50(num_classes=128)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/moco-master/moco_v2_800ep_pretrain.pth.tar'
# state_dict = torch.load(weights_path, map_location='cpu')
# pretrained_dict = state_dict['state_dict']
# net_dict = net.state_dict()
# pretrained_dict = {'.'.join(k.split('.')[2:]): v for k, v in pretrained_dict.items() if '.'.join(k.split('.')[2:]) in net_dict}
# net_dict.update(pretrained_dict)
# net.load_state_dict(net_dict)
# net.fc = nn.Linear(2048, 2)
# net.fc.weight.data.normal_(mean=0.0, std=0.01)
# net.fc.bias.data.zero_()

# for name, param in net.named_parameters():
#     if name not in ['fc.weight', 'fc.bias']:
#         param.requires_grad = False

# net.fc.weight.data.normal_(mean=0.0, std=0.01)
# net.fc.bias.data.zero_()
########################################################################################################

########################################### 加载ImageNet模型 ############################################
net_name = 'vgg16ImageNet'
net = torchvision.models.vgg16_bn(pretrained=False)
weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/vgg16_bn-6c64b313.pth'
state_dict = torch.load(weights_path)
net.load_state_dict(state_dict)
net.classifier[6] = nn.Linear(4096, 2)
# net.fc = nn.Linear(1000, 2)
fineturn = False
if fineturn:
    for p in net.parameters():
        p.requires_grad=False
    frozen_layers = [net.features[37],net.features[38],net.features[39],net.features[40], net.features[41],net.features[42],net.features[43],
                    net.avgpool, net.classifier, 
                    # net.fc,
                    ]
    for layer in frozen_layers:
        for name, value in layer.named_parameters():
            value.requires_grad = True

# net_name = 'vgg19ImageNet'
# net = torchvision.models.vgg19_bn(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/vgg19_bn-c79401a0.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.classifier[6] = nn.Linear(4096, 2)
# # net.fc = nn.Linear(net.fc.in_features, 2)
# fineturn = False
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.features[27],net.features[28],net.features[29],net.features[30],net.features[31],net.features[32],net.features[33],net.features[34],net.features[35],net.features[36],
#                     net.features[37], net.features[38], net.features[39], net.features[40], net.features[41], net.features[42], net.features[43],net.features[44],net.features[45],net.features[46], net.features[47],net.features[48],net.features[49],
#                     net.features[50],net.features[51],net.features[52],
#                     net.avgpool, net.classifier, 
#                     # net.fc,
#                     ]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True

# net_name = 'Resnet18ImageNet'
# net = torchvision.models.resnet18(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/resnet18-5c106cde.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.fc = nn.Linear(net.fc.in_features, 2)
# fineturn = False
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.layer1, net.layer2, net.layer3, net.layer4, net.avgpool, net.fc]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True            

# net_name = 'Resnet34ImageNet'
# net = torchvision.models.resnet34(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/resnet34-333f7ec4.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# net.fc = nn.Linear(net.fc.in_features, 2)
# fineturn = False
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.layer1, net.layer2, net.layer3, net.layer4, net.avgpool, net.fc]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True    

# net_name = 'mobilenetv2ImageNet'
# net = torchvision.models.mobilenet_v2(pretrained=False)
# weights_path = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/ImageNet/mobilenet_v2-b0353104.pth'
# state_dict = torch.load(weights_path)
# net.load_state_dict(state_dict)
# # net.fc = nn.Linear(net.fc.in_features, 2)
# net.classifier[1] = nn.Linear(1280, 2)
# fineturn = False
# if fineturn:
#     for p in net.parameters():
#         p.requires_grad=False
#     frozen_layers = [net.features[10],net.features[11],net.features[12],net.features[13], net.features[14], net.features[15], net.features[16], net.features[17], net.features[18], net.classifier]
#     for layer in frozen_layers:
#         for name, value in layer.named_parameters():
#             value.requires_grad = True    
########################################################################################################


net = net.to(device)
if device == 'cuda':
    # net = torch.nn.DataParallel(net)
    cudnn.benchmark = True
########################################################################################

##################################### 加载样本 ###################################################

########################################################################################
# transform_train = transforms.Compose([
#     # transforms.RandomCrop(32, padding=4),
#     # np.float32,
#     transforms.Resize((224, 224)),
#     transforms.RandomHorizontalFlip(),
#     ImageNetPolicy(),
#     # CIFAR10Policy(),
#     transforms.ToTensor(),
#     # fixed_image_standardization,
#     # transforms.Normalize((129.186279296875, 104.76238250732422, 93.59396362304688), (1, 1, 1)),  # vgg_face_dag_momo
#     # transforms.Normalize((131.45376586914062, 103.98748016357422, 91.46234893798828), (1, 1, 1)),  # vgg_m_face_bn_dag_momo
#     # transforms.Normalize(tuple(net.meta['mean']), tuple(net.meta['std'])),
#     transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
# ])

# transform_test = transforms.Compose([
#     # np.float32,
#     transforms.Resize((224, 224)),
#     transforms.ToTensor(),
#     # fixed_image_standardization,
#     # transforms.Normalize((129.186279296875, 104.76238250732422, 93.59396362304688), (1, 1, 1)),  # # vgg_face_dag_momo
#     # transforms.Normalize((131.45376586914062, 103.98748016357422, 91.46234893798828), (1, 1, 1)),  # vgg_m_face_bn_dag_momo
#     # transforms.Normalize(tuple(net.meta['mean']), tuple(net.meta['std'])),
#     transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
# ])
########################################################################################

########################################################################################
transform_train = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.Scale((224,224)),
    transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.4),
    transforms.RandomRotation(5, resample=False,expand=False, center=None),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
])

transform_val = transforms.Compose([
    transforms.Scale((224,224)),
    transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.4),
    transforms.RandomRotation(5, resample=False,expand=False, center=None),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
])

transform_test = transforms.Compose([
    transforms.Scale((224,224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])  # 用moco模型的时候不要注释掉
])
########################################################################################


# trainset = torchvision.datasets.CIFAR10(
#     root='./data', train=True, download=True, transform=transform_train)
data_root = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/12_细细姐_正常和有病分类/2_图像_经过mtcnn检测和对齐_112_加上检测不出来的人脸_分train_val和test/2_图像_经过mtcnn检测和对齐_112_加上检测不出来的人脸_分train_val和test_4'
trainset = torchvision.datasets.ImageFolder(
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/facenet_pytorch_master/data/4_mtcnn_256_88_检测不到人脸的加上_横着的旋转过来_train_test/train',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类威廉和非威廉/train', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类正常和有病/train', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_mtcnn_256_44_一人一张_威廉_非威廉/train', 
    # root = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/11_NTS的威廉和正常/train',
    root= data_root + '/train', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_dlib加手动对齐_一人一张_威廉_非威廉_5折交叉检验/5_dlib加手动对齐_一人一张_威廉_非威廉_0/train',
    transform=transform_train)
trainloader = torch.utils.data.DataLoader(
    trainset, batch_size=16, shuffle=True, num_workers=0, drop_last=True)

# testset = torchvision.datasets.CIFAR10(
#     root='./data', train=False, download=True, transform=transform_test)
testset = torchvision.datasets.ImageFolder(
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/facenet_pytorch_master/data/4_mtcnn_256_88_检测不到人脸的加上_横着的旋转过来_train_test/test', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类威廉和非威廉/test',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类正常和有病/test',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_mtcnn_256_44_一人一张_威廉_非威廉/test', 
    # root = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/11_NTS的威廉和正常/test',
    root= data_root + '/val', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_dlib加手动对齐_一人一张_威廉_非威廉_5折交叉检验/5_dlib加手动对齐_一人一张_威廉_非威廉_0/val',
    transform=transform_val)
testloader = torch.utils.data.DataLoader(
    testset, batch_size=8, shuffle=False, num_workers=0, drop_last=False)

testset_2 = torchvision.datasets.ImageFolder(
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/facenet_pytorch_master/data/4_mtcnn_256_88_检测不到人脸的加上_横着的旋转过来_train_test/test', 
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类威廉和非威廉/test',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/4_mtcnn_256_44_检测不到人脸的加上_横着的旋转过来_train_test_一人多张_分类正常和有病/test',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_mtcnn_256_44_一人一张_威廉_非威廉/test', 
    # root = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/11_NTS的威廉和正常/test',
    root = data_root + '/test',
    # root='/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/dataset/5_dlib加手动对齐_一人一张_威廉_非威廉_5折交叉检验/5_dlib加手动对齐_一人一张_威廉_非威廉/test', 

    transform=transform_test)
testloader_2 = torch.utils.data.DataLoader(
    testset_2, batch_size=8, shuffle=False, num_workers=0, drop_last=False)

########################################################################################

if args.resume:
    # Load checkpoint.
    print('==> Resuming from checkpoint..')
    assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
    checkpoint = torch.load('./checkpoint/ckpt.pth')
    net.load_state_dict(checkpoint['net'])
    best_acc = checkpoint['acc']
    start_epoch = checkpoint['epoch']

criterion = nn.CrossEntropyLoss()
if fineturn:
    optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=args.lr, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=10,factor=0.5,min_lr=1e-8)
else:
    optimizer = optim.SGD(net.parameters(), lr=args.lr, momentum=0.9, weight_decay=5e-4)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=10,factor=0.5,min_lr=1e-8)


# Training
def train(epoch, writer):
    print('\nEpoch: %d' % epoch)
    net.train()
    train_loss = 0
    correct = 0
    total = 0

    targets_list = []
    predicted_list = []

    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = net(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        # writer.add_scalars('loss', loss.item(), epoch* + batch_idx)
        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d) | lr: %f'
                     % (train_loss/(batch_idx+1), 100.*correct/total, correct, total, optimizer.state_dict()['param_groups'][0]['lr']))

        targets_list.append(targets.cpu())
        predicted_list.append(predicted.cpu())

    targets_list = torch.cat(targets_list, dim=0)
    predicted_list = torch.cat(predicted_list, dim=0)

    precision_epoch = precision_score(targets_list, predicted_list)
    recall_epoch = recall_score(targets_list, predicted_list)
    f1_epoch = f1_score(targets_list, predicted_list)

    fpr, tpr, thresholds = metrics.roc_curve(targets_list, predicted_list)
    auc_epoch = metrics.auc(fpr, tpr)

    writer.add_scalar('Train/train_loss_epoch', train_loss/len(trainloader), epoch)
    writer.add_scalar('Train/train_acc_epoch', correct/total, epoch)
    writer.add_scalar('Train/train_precision_epoch', precision_epoch, epoch)
    writer.add_scalar('Train/train_recall_epoch', recall_epoch, epoch)
    writer.add_scalar('Train/train_f1_epoch', f1_epoch, epoch)
    writer.add_scalar('Train/train_auc_epoch', auc_epoch, epoch)
    writer.add_scalar('Train/lr', optimizer.state_dict()['param_groups'][0]['lr'], epoch)

    with open(csv_path_train,"a") as csvfile: 
        writer_csv = csv.writer(csvfile)
    
        # writer_csv.writerow(["epoch","loss","acc", "precision", "recall", "f1", "auc"])

        writer_csv.writerow([epoch, train_loss/len(trainloader), correct/total, precision_epoch, recall_epoch, f1_epoch, auc_epoch])

        # writer_csv.writerow([{"epoch":epoch, "loss":train_loss/len(trainloader), "acc":correct/total, "precision":precision_epoch, "recall":recall_epoch, "f1":f1_epoch, "auc":auc_epoch}])

def test_2_in_test_process():
    net.eval()
    test_loss = 0
    correct = 0
    total = 0

    targets_list = []
    predicted_list = []
    prob_list = []

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader_2):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader_2), 'Loss_test: %.3f | Acc_test: %.3f%% (%d/%d)'
                         % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

            targets_list.append(targets.cpu())
            predicted_list.append(predicted.cpu())
            prob = F.softmax(outputs, dim=1)[:,1]
            prob_list.append(prob.cpu())

    targets_list = torch.cat(targets_list, dim=0)
    predicted_list = torch.cat(predicted_list, dim=0)
    prob_list = torch.cat(prob_list, dim=0)
    
    acc_epoch = correct/total
    precision_epoch = precision_score(targets_list, predicted_list)
    recall_epoch = recall_score(targets_list, predicted_list)
    f1_epoch = f1_score(targets_list, predicted_list)

    fpr, tpr, thresholds = metrics.roc_curve(targets_list, prob_list)
    auc_epoch = metrics.auc(fpr, tpr)

    tn, fp, fn, tp = confusion_matrix(targets_list, predicted_list).ravel()
    specificity_epoch = tn / float(tn+fp)

    targets_list_path = os.path.join(PATH_to_log_dir, 'targets_list_test_in_val_process_{}.npy'.format(epoch))
    np.save(targets_list_path, targets_list)
    predicted_list_path = os.path.join(PATH_to_log_dir, 'predicted_list_test_in_val_process_{}.npy'.format(epoch))
    np.save(predicted_list_path, predicted_list)
    prob_list_path = os.path.join(PATH_to_log_dir, 'prob_list_test_in_val_process_{}.npy'.format(epoch))
    np.save(prob_list_path, prob_list)

    return test_loss/len(testloader_2), tn, fp, fn, tp, correct/total, specificity_epoch, precision_epoch, recall_epoch, f1_epoch, auc_epoch


def test(epoch, writer):
    global best_acc
    net.eval()
    test_loss = 0
    correct = 0
    total = 0

    targets_list = []
    predicted_list = []
    prob_list = []

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                         % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

            targets_list.append(targets.cpu())
            predicted_list.append(predicted.cpu())
            prob = F.softmax(outputs, dim=1)[:,1]
            prob_list.append(prob.cpu())

    scheduler.step(test_loss/len(testloader))

    targets_list = torch.cat(targets_list, dim=0)
    predicted_list = torch.cat(predicted_list, dim=0)
    prob_list = torch.cat(prob_list, dim=0)
    
    acc_epoch = correct/total
    precision_epoch = precision_score(targets_list, predicted_list)
    recall_epoch = recall_score(targets_list, predicted_list)
    f1_epoch = f1_score(targets_list, predicted_list)

    fpr, tpr, thresholds = metrics.roc_curve(targets_list, prob_list)
    auc_epoch = metrics.auc(fpr, tpr)

    tn, fp, fn, tp = confusion_matrix(targets_list, predicted_list).ravel()
    specificity_epoch = tn / float(tn+fp)

    writer.add_scalar('Test/test_loss_epoch', test_loss/len(testloader), epoch)
    writer.add_scalar('Test/test_acc_epoch', acc_epoch, epoch)
    writer.add_scalar('Test/test_precision_epoch', precision_epoch, epoch)
    writer.add_scalar('Test/test_recall_epoch', recall_epoch, epoch)
    writer.add_scalar('Test/test_f1_epoch', f1_epoch, epoch)
    writer.add_scalar('Test/test_auc_epoch', auc_epoch, epoch)
    writer.add_scalar('Test/test_specificity_epoch', specificity_epoch, epoch)
    writer.add_scalar('Test/lr_epoch', optimizer.state_dict()['param_groups'][0]['lr'], epoch)
    writer.flush()

    with open(csv_path_test,"a") as csvfile: 
        writer_csv = csv.writer(csvfile)
        # writer_csv.writerow(["epoch","loss", "TN", "FP", "FN", "TP", "acc", "specificity", "precision", "recall", "f1", "auc"])
        writer_csv.writerow([epoch, test_loss/len(testloader), tn, fp, fn, tp, correct/total, specificity_epoch, precision_epoch, recall_epoch, f1_epoch, auc_epoch])

    
    acc = 100.*correct/total
    # if acc >= best_acc:
    if acc >= best_acc:
        print('Saving..')
        state = {
            'net': net.state_dict(),
            'acc': acc,
            'epoch': epoch,
        }

        checkpoint_path = os.path.join(PATH_to_log_dir, 'ckpt_{:d}.pth'.format(epoch))  
        torch.save(state, checkpoint_path)
        best_acc = acc

        targets_list_path = os.path.join(PATH_to_log_dir, 'targets_list_val_{}.npy'.format(epoch))
        np.save(targets_list_path, targets_list)
        predicted_list_path = os.path.join(PATH_to_log_dir, 'predicted_list_val_{}.npy'.format(epoch))
        np.save(predicted_list_path, predicted_list)
        prob_list_path = os.path.join(PATH_to_log_dir, 'prob_list_val_{}.npy'.format(epoch))
        np.save(prob_list_path, prob_list)

        roc_path = os.path.join(PATH_to_log_dir, 'roc_valid_epoch_{}.png'.format(epoch))
        plot_roc(fpr, tpr, figure_name=roc_path)
        roc_path = os.path.join(PATH_to_log_dir, 'roc_valid_epoch_{}.pdf'.format(epoch))
        plot_roc(fpr, tpr, figure_name=roc_path)

        loss_, tn_, fp_, fn_, tp_, acc_, specificity_epoch_, precision_epoch_, recall_epoch_, f1_epoch_, auc_epoch_ = test_2_in_test_process()
        with open(csv_path_test_2_in_test_process,"a") as csvfile: 
            writer_csv = csv.writer(csvfile)
            writer_csv.writerow([epoch, test_loss/len(testloader), correct/total, tn_, fp_, fn_, tp_, acc_, specificity_epoch_, precision_epoch_, recall_epoch_, f1_epoch_, auc_epoch_])


def test_2(epoch, writer):
    global best_acc_2
    net.eval()
    test_loss = 0
    correct = 0
    total = 0

    targets_list = []
    predicted_list = []
    prob_list = []

    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader_2):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader_2), 'Loss_test: %.3f | Acc_test: %.3f%% (%d/%d)'
                         % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

            targets_list.append(targets.cpu())
            predicted_list.append(predicted.cpu())
            prob = F.softmax(outputs, dim=1)[:,1]
            prob_list.append(prob.cpu())

    targets_list = torch.cat(targets_list, dim=0)
    predicted_list = torch.cat(predicted_list, dim=0)
    prob_list = torch.cat(prob_list, dim=0)
    
    acc_epoch = correct/total
    precision_epoch = precision_score(targets_list, predicted_list)
    recall_epoch = recall_score(targets_list, predicted_list)
    f1_epoch = f1_score(targets_list, predicted_list)

    fpr, tpr, thresholds = metrics.roc_curve(targets_list, prob_list)
    auc_epoch = metrics.auc(fpr, tpr)

    tn, fp, fn, tp = confusion_matrix(targets_list, predicted_list).ravel()
    specificity_epoch = tn / float(tn+fp)

    writer.add_scalar('Test_2/test_loss_epoch', test_loss/len(testloader_2), epoch)
    writer.add_scalar('Test_2/test_acc_epoch', acc_epoch, epoch)
    writer.add_scalar('Test_2/test_precision_epoch', precision_epoch, epoch)
    writer.add_scalar('Test_2/test_recall_epoch', recall_epoch, epoch)
    writer.add_scalar('Test_2/test_f1_epoch', f1_epoch, epoch)
    writer.add_scalar('Test_2/test_auc_epoch', auc_epoch, epoch)
    writer.add_scalar('Test_2/test_specificity_epoch', specificity_epoch, epoch)
    writer.flush()

    with open(csv_path_test_2,"a") as csvfile: 
        writer_csv = csv.writer(csvfile)
        # writer_csv.writerow(["epoch","loss", "TN", "FP", "FN", "TP", "acc", "specificity", "precision", "recall", "f1", "auc"])
        writer_csv.writerow([epoch, test_loss/len(testloader_2), tn, fp, fn, tp, correct/total, specificity_epoch, precision_epoch, recall_epoch, f1_epoch, auc_epoch])

    # Save checkpoint.
    
    acc = 100.*correct/total
    if acc >= best_acc_2:
        print('Saving..')
        state = {
            'net': net.state_dict(),
            'acc': acc,
            'epoch': epoch,
        }
        # if not os.path.isdir('checkpoint'):
        #     os.mkdir('checkpoint')
        checkpoint_path = os.path.join(PATH_to_log_dir, 'ckpt_test.pth')    
        torch.save(state, checkpoint_path)
        best_acc_2 = acc

        targets_list_path = os.path.join(PATH_to_log_dir, 'targets_list_test_{}.npy'.format(epoch))
        np.save(targets_list_path, targets_list)
        predicted_list_path = os.path.join(PATH_to_log_dir, 'predicted_list_test_{}.npy'.format(epoch))
        np.save(predicted_list_path, predicted_list)
        prob_list_path = os.path.join(PATH_to_log_dir, 'prob_list_test_{}.npy'.format(epoch))
        np.save(prob_list_path, prob_list)

    # if acc >= best_acc_2:
        roc_path = os.path.join(PATH_to_log_dir, 'roc_valid_epoch_test_{}.png'.format(epoch))
        plot_roc(fpr, tpr, figure_name=roc_path)

        roc_path = os.path.join(PATH_to_log_dir, 'roc_valid_epoch_test_{}.pdf'.format(epoch))
        plot_roc(fpr, tpr, figure_name=roc_path)

from tensorboardX import SummaryWriter 
PATH_to_log_dir = '/media/mozihua/My_Passport/My_program_work/liuhui_work_momo/VGGface/train_test_method/pytorch-cifar-master/tensorboard_log_细细姐_train和val和test的5折验证/2_常规增强_MTCNN_net:{}_lr:{}_fineturn:{}_一人一张_分类威廉和非威廉_第4折_看看每个epoch的test的性能_{}'.format(str(net_name), str(args.lr), str(fineturn), str(str(datetime.datetime.now())[:19]))
writer = SummaryWriter(PATH_to_log_dir)

csv_path_train = os.path.join(PATH_to_log_dir, 'train.csv')
with open(csv_path_train,"a") as csvfile: 
    writer_csv_train = csv.writer(csvfile)  # tn, fp, fn, tp
    writer_csv_train.writerow(["epoch","loss", "acc", "precision", "recall", "f1", "auc"])

csv_path_test = os.path.join(PATH_to_log_dir, 'test.csv')
with open(csv_path_test,"a") as csvfile: 
    writer_csv_test = csv.writer(csvfile)
    writer_csv_test.writerow(["epoch","loss", "TN", "FP", "FN", "TP", "acc", "specificity", "precision", "recall", "f1", "auc"])

csv_path_test_2_in_test_process = os.path.join(PATH_to_log_dir, 'test_2_in_test_process.csv')
with open(csv_path_test_2_in_test_process,"a") as csvfile: 
    writer_csv_test = csv.writer(csvfile)
    writer_csv_test.writerow(["epoch","val_loss", "val_acc", "test_TN", "test_FP", "test_FN", "test_TP", "test_acc", "test_specificity", "test_precision", "test_recall", "test_f1", "test_auc"])

csv_path_test_2 = os.path.join(PATH_to_log_dir, 'test_2.csv')
with open(csv_path_test_2,"a") as csvfile: 
    writer_csv_test = csv.writer(csvfile)
    writer_csv_test.writerow(["epoch","loss", "TN", "FP", "FN", "TP", "acc", "specificity", "precision", "recall", "f1", "auc"])

for epoch in range(start_epoch, start_epoch+100):
    train(epoch, writer)
    test(epoch, writer)
    test_2(epoch, writer)

writer.close()

print('Done')