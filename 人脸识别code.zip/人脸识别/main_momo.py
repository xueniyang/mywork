'''Train CIFAR10 with PyTorch.'''
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import torch.backends.cudnn as cudnn

import torchvision
import torchvision.transforms as transforms

import os
import argparse

from models import *
from utils import progress_bar

from models_pix2pix import networks
from models_pix2pix.networks import get_norm_layer, UnetGenerator, init_weights

####################################### 定义pix2pix的unet_256 #######################################
def Conv1x1BNReLU(in_channels,out_channels):
    return nn.Sequential(
        nn.Conv2d(in_channels=in_channels,out_channels=out_channels,kernel_size=1,stride=1,padding=0),
        nn.BatchNorm2d(out_channels),
        nn.ReLU6(inplace=True)
    )
def __patch_instance_norm_state_dict(state_dict, module, keys, i=0):
    """Fix InstanceNorm checkpoints incompatibility (prior to 0.4)"""
    key = keys[i]
    if i + 1 == len(keys):  # at the end, pointing to a parameter/buffer
        if module.__class__.__name__.startswith('InstanceNorm') and \
                (key == 'running_mean' or key == 'running_var'):
            if getattr(module, key) is None:
                state_dict.pop('.'.join(keys))
        if module.__class__.__name__.startswith('InstanceNorm') and \
            (key == 'num_batches_tracked'):
            state_dict.pop('.'.join(keys))
    else:
        __patch_instance_norm_state_dict(state_dict, getattr(module, key), keys, i + 1)

class VggNet(nn.Module):
    def __init__(self, num_classes=3):
        super(VggNet, self).__init__()
        self.input_nc = 3
        self.output_nc = 3
        self.ngf = 64
        self.netG = 'unet_256'
        self.norm = 'batch'
        self.no_dropout = False
        self.init_type = 'normal'
        self.init_gain = 0.02
        self.gpu_ids = []

        norm_layer = get_norm_layer(norm_type=self.norm)
        # self.net = UnetGenerator(self.input_nc, self.output_nc, 8, self.ngf, norm_layer=self.norm_layer, use_dropout=not self.no_dropout)
        self.net = networks.define_G(self.input_nc, self.output_nc, self.ngf, self.netG, self.norm, not self.no_dropout, self.init_type, self.init_gain, self.gpu_ids)
        init_weights(self.net, self.init_type, init_gain=self.init_gain)

        self.model_names = ['G']
        self.load_suffix = 'latest'
        self.pth_save_dir = '/media/mozihua/My_Passport/liuhui_work_momo/faceCircleMask_3nc3nc_pix2pix_unet256_AtoB_1000epochs_gpu_L1_lsgan'
        self.device = 'cpu'

        def __patch_instance_norm_state_dict(state_dict, module, keys, i=0):
            """Fix InstanceNorm checkpoints incompatibility (prior to 0.4)"""
            key = keys[i]
            if i + 1 == len(keys):  # at the end, pointing to a parameter/buffer
                if module.__class__.__name__.startswith('InstanceNorm') and \
                        (key == 'running_mean' or key == 'running_var'):
                    if getattr(module, key) is None:
                        state_dict.pop('.'.join(keys))
                if module.__class__.__name__.startswith('InstanceNorm') and \
                    (key == 'num_batches_tracked'):
                    state_dict.pop('.'.join(keys))
            else:
                __patch_instance_norm_state_dict(state_dict, getattr(module, key), keys, i + 1)

        for name in self.model_names:
            if isinstance(name, str):
                load_filename = '%s_net_%s.pth' % (self.load_suffix, name)
                load_path = os.path.join(self.pth_save_dir, load_filename)

                # net = getattr('net' + name)
                # if isinstance(net, torch.nn.DataParallel):
                #     net = net.module

                state_dict = torch.load(load_path, map_location=str(self.device))
                if hasattr(state_dict, '_metadata'):
                    del state_dict._metadata
                for key in list(state_dict.keys()):
                    __patch_instance_norm_state_dict(state_dict, self.net, key.split('.'))
                
                self.net.load_state_dict(state_dict)

        self.feature = nn.Sequential( 
                                self.net.model.model[0],  # 0 Conv2d(3, 64, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[0],  # 1 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[1],  # 2 Conv2d(64, 128, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[2],  # 3 BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[0],  # 4 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[3].model[1],  # 5 Conv2d(128, 256, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[3].model[2],  # 6 BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[3].model[0],  # 7 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[3].model[3].model[1],  # 8 Conv2d(256, 512, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[3].model[3].model[2],  # 9 BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[0],  # 10 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[1],  # 11 Conv2d(512, 512, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[3].model[3].model[3].model[2],  # 12 BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[0],  # 13 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[1],  # 14 Conv2d(512, 512, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[2],  # 15 BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[3].model[0],  # 16 LeakyReLU(negative_slope=0.2, inplace=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[3].model[1],  # 17 Conv2d(512, 512, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[3].model[2],  # 18 BatchNorm2d(512, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
                                self.net.model.model[1].model[3].model[3].model[3].model[3].model[3].model[3].model[0],  # 19 LeakyReLU(negative_slope=0.2, inplace=True)
                                # self.net.model.model[1].model[3].model[3].model[3].model[3].model[3].model[3].model[1],  # 20 Conv2d(512, 512, kernel_size=(4, 4), stride=(2, 2), padding=(1, 1), bias=False)
                                # nn.BatchNorm2d(512),
                                # nn.ReLU(True),
                                )
        self.classifier = nn.Sequential(
                                Conv1x1BNReLU(in_channels=512, out_channels=num_classes),
                                nn.AdaptiveAvgPool2d(1),
                                )

        # self.classifier = nn.Sequential(
        #     nn.Linear(in_features=512*7*7,out_features=4096),
        #     nn.Dropout(p=0.2),
        #     nn.Linear(in_features=4096, out_features=4096),
        #     nn.Dropout(p=0.2),
        #     nn.Linear(in_features=4096, out_features=num_classes)
        # )

        self.softmax = nn.Softmax(dim=1)

        del self.net


    def _init_params(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.feature(x)
        
        x = self.classifier(x)

        
        x = torch.squeeze(x, dim=3).contiguous()
        x = torch.squeeze(x, dim=2).contiguous()
        out = self.softmax(x)
        return out

####################################################################################################
net = VggNet(num_classes=3)

for m in net.classifier.modules():
    if isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)

parser = argparse.ArgumentParser(description='PyTorch CIFAR10 Training')
parser.add_argument('--lr', default=0.001, type=float, help='learning rate')
parser.add_argument('--resume', '-r', action='store_true',
                    help='resume from checkpoint')
args = parser.parse_args()

# device = 'cuda' if torch.cuda.is_available() else 'cpu'
device = 'cpu'
best_acc = 0  # best test accuracy
start_epoch = 0  # start from epoch 0 or last checkpoint epoch

# Data
print('==> Preparing data..')
# transform_train = transforms.Compose([
#     transforms.RandomCrop(32, padding=4),
#     transforms.RandomHorizontalFlip(),
#     transforms.ToTensor(),
#     transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
# ])
transform_train = transforms.Compose([
    transforms.RandomCrop(256, padding=0),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset_root = '/media/mozihua/My_Passport/liuhui_work_momo/222222/pytorch_cifar_classification/data/HC_WBS_Other_dataset/train/'
trainset = torchvision.datasets.ImageFolder(root=trainset_root, transform=transform_train)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=32, shuffle=True, num_workers=0)

testset_root = '/media/mozihua/My_Passport/liuhui_work_momo/222222/pytorch_cifar_classification/data/HC_WBS_Other_dataset/test/'
testset = torchvision.datasets.ImageFolder(root=testset_root, transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=16, shuffle=True, num_workers=0)


# trainset = torchvision.datasets.CIFAR10(
#     root='./data', train=True, download=True, transform=transform_train)
# trainloader = torch.utils.data.DataLoader(
#     trainset, batch_size=128, shuffle=True, num_workers=2)

# testset = torchvision.datasets.CIFAR10(
#     root='./data', train=False, download=True, transform=transform_test)
# testloader = torch.utils.data.DataLoader(
#     testset, batch_size=100, shuffle=False, num_workers=2)

# classes = ('plane', 'car', 'bird', 'cat', 'deer',
#            'dog', 'frog', 'horse', 'ship', 'truck')

classes = ('0', '1', '2')

# Model
print('==> Building model..')
# net = VGG('VGG19')
# net = ResNet18()
# net = PreActResNet18()
# net = GoogLeNet()
# net = DenseNet121()
# net = ResNeXt29_2x64d()
# net = MobileNet()
# net = MobileNetV2()
# net = DPN92()
# net = ShuffleNetG2()
# net = SENet18()
# net = ShuffleNetV2(1)
# net = EfficientNetB0()
# net = RegNetX_200MF()
net = net.to(device)
if device == 'cuda':
    net = torch.nn.DataParallel(net)
    cudnn.benchmark = True

if args.resume:
    # Load checkpoint.
    print('==> Resuming from checkpoint..')
    assert os.path.isdir('checkpoint'), 'Error: no checkpoint directory found!'
    checkpoint = torch.load('./checkpoint/ckpt.pth')
    net.load_state_dict(checkpoint['net'])
    best_acc = checkpoint['acc']
    start_epoch = checkpoint['epoch']

criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(net.parameters(), lr=args.lr,
                      momentum=0.9, weight_decay=5e-4)


# Training
def train(epoch):
    print('\nEpoch: %d' % epoch)
    net.train()
    train_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = net(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        train_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                     % (train_loss/(batch_idx+1), 100.*correct/total, correct, total))


def test(epoch):
    global best_acc
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(testloader):
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = net(inputs)
            loss = criterion(outputs, targets)

            test_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

            progress_bar(batch_idx, len(testloader), 'Loss: %.3f | Acc: %.3f%% (%d/%d)'
                         % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))

    # Save checkpoint.
    acc = 100.*correct/total
    if acc > best_acc:
        print('Saving..')
        state = {
            'net': net.state_dict(),
            'acc': acc,
            'epoch': epoch,
        }
        if not os.path.isdir('checkpoint'):
            os.mkdir('checkpoint')
        torch.save(state, './checkpoint/ckpt.pth')
        best_acc = acc


for epoch in range(start_epoch, start_epoch+200):
    train(epoch)
    test(epoch)
